//
//  AiyaCameraEffect.h
//  AiyaCameraSDK
//
//  Created by 汪洋 on 2016/10/26.
//  Copyright © 2016年 深圳哎吖科技. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>

typedef NS_ENUM(NSUInteger, AIYA_CAMERA_EFFECT_ERROR_CODE) {
    AIYA_CAMERA_EFFECT_ERROR_CODE_NO_ERROR, /** 没有错误 */
    AIYA_CAMERA_EFFECT_ERROR_CODE_INVALID_RESOURCE, /** 无效的资源 */
};

@interface AiyaCameraEffect : NSObject

/**
 初始化上下文
 
 @param width 保留字段,传0
 @param height 保留字段,传0
 */
- (void)initEffectContextWithWidth:(GLuint)width height:(GLuint)height;

/**
 更新人脸跟踪数据

 @param byteBuffer BGRA数据
 @param width 数据宽度
 @param height 数据高度
 */
- (void)trackFaceWithByteBuffer:(GLubyte *)byteBuffer width:(GLuint)width height:(GLuint)height;

/**
 对纹理数据进行美颜
 
 @param texture 纹理数据
 @param width 纹理数据宽度
 @param height 纹理数据高度
 @param beautyType 美颜类型
 @param beautyLevel 美颜等级
 */
- (void)beautifyFaceWithTexture:(GLuint)texture width:(GLuint)width height:(GLuint)height beautyType:(NSUInteger)beautyType beautyLevel:(NSUInteger) beautyLevel;


/**
 对纹理进行磨皮处理

 @param texture 纹理数据
 @param width 纹理数据宽度
 @param height 纹理数据高度
 @param intensity 强度
 @param type 类型
 */
- (void)smoothSkinWithTexture:(GLuint)texture width:(GLuint)width height:(GLuint)height intensity:(float)intensity type:(NSInteger)type;


/**
 对纹理进行美白处理

 @param texture 纹理数据
 @param width 纹理数据宽度
 @param height 纹理数据高度
 @param intensity 强度
 @param type 类型
 */
- (void)whitenSkinWithTexture:(GLuint)texture width:(GLuint)width height:(GLuint)height intensity:(float)intensity type:(NSInteger)type;

/**
 绘制大眼特效
 
 @param texture 纹理数据
 @param width 纹理数据宽度
 @param height 理数据高度
 */
- (void)bigEyesWithTexture:(GLuint)texture width:(GLuint)width height:(GLuint)height bigEyesScale:(float)bigEyesScale;

/**
 绘制瘦脸特效
 
 @param texture 纹理数据
 @param width 纹理数据宽度
 @param height 理数据高度
 */
- (void)slimFaceWithTexture:(GLuint)texture width:(GLuint)width height:(GLuint)height slimFaceScale:(float)slimFaceScale;

/**
 绘制特效
 
 @param texture 保留字段,传0
 @param width 宽度
 @param height 高度
 @param effectPath 特效资源路径
 @param errorCode 错误码
 @return 绘制结果
 */
- (int)effectWithTexture:(GLuint)texture width:(GLuint)width height:(GLuint)height effectPath:(NSString *)effectPath  error:(AIYA_CAMERA_EFFECT_ERROR_CODE *)errorCode;

/**
 销毁上下文
 */
- (void)deinitEffectContext;
@end
