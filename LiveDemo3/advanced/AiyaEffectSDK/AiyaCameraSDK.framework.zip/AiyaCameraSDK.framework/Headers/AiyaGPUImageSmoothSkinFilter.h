//
//  AiyaGPUImageSmoothSkinFilter.h
//  AiyaCameraSDK
//
//  Created by 汪洋 on 2017/7/22.
//  Copyright © 2017年 深圳哎吖科技. All rights reserved.
//

#import "AYGPUImageFilter.h"
#import "AiyaCameraEffect.h"

typedef NS_ENUM(NSUInteger, AIYA_SMOOTH_SKIN_TYPE) {
    AIYA_SMOOTH_SKIN_TYPE_0 = 0x10,
};

@interface AiyaGPUImageSmoothSkinFilter : AYGPUImageFilter

@property (nonatomic, assign) CGFloat intensity;

@property (nonatomic, assign) AIYA_SMOOTH_SKIN_TYPE type;

- (id)initWithAiyaCameraEffect:(AiyaCameraEffect *)cameraEffect;

@end
